from flask import Flask, render_template, send_from_directory
import os

app = Flask(__name__)

@app.route('/')
def index():
    videos = [v for v in os.listdir('videos') if v.endswith('.mp4')]
    return render_template('index.html', videos=videos)

@app.route('/watch/<video>')
def watch(video):
    return render_template('watch.html', video=video)

@app.route('/video/<path:filename>')
def serve_video(filename):
    return send_from_directory('videos', filename)

@app.route('/thumb/<path:filename>')
def serve_thumb(filename):
    return send_from_directory('thumbs', filename)

if __name__ == '__main__':
    app.run(debug=True)